# 3D Studio APK (GitHub se)
1. GitHub pe naya repo banao (empty).
2. Is folder ki saari files upload/push karo (www/, .github/, package.json, capacitor.config.json, .gitignore).
3. Repo > Actions tab > "Build APK" chalne do (push par apne aap chalta hai).
4. Run khatam hone par neeche Artifacts se "studio3d-apk" download karo, zip kholo, app-debug.apk phone mein install karo.
App badalna ho to sirf www/index.html badlo aur push karo.
